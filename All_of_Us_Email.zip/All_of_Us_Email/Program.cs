﻿using System;
using System.Net.Mail;
using System.Net;
using System.Data;
using System.IO;
using CsvHelper;
using System.Threading;

namespace All_of_Us_Email
{
    class Program
    {
        static void Main(string[] args)
        {
            DataTable _recipients = __readCSV(@"\\tsclient\Desktop\All of Us Letter Sending\2017-12-07 20 Emails GHEI.csv");

            Console.WriteLine("# of participants in the file: " + _recipients.Rows.Count.ToString("N0")); Console.WriteLine();

            for (int i = 0; i < _recipients.Rows.Count; i++)
            {
                string _study_id = _recipients.Rows[i]["study_id"].ToString();
                string _name = __prepareName(_recipients.Rows[i]["first_name"].ToString()) + " " + __prepareName(_recipients.Rows[i]["last_name"].ToString());
                string _email_address = _recipients.Rows[i]["email_address"].ToString().ToLower();
                string _nih_invitation_code = _recipients.Rows[i]["nih_invitation_code"].ToString();
                Console.WriteLine((i + 1).ToString() + ", " + _study_id + ", " + _name + ", " + _email_address + ", " + _nih_invitation_code);
            }

            Console.Write("\ncontinue? (y/n): "); if (Console.ReadLine() == "n") return; Console.WriteLine();

            for (int i = 0; i < _recipients.Rows.Count; i++)
            {
                string _study_id = _recipients.Rows[i]["study_id"].ToString();
                string _name = __prepareName(_recipients.Rows[i]["first_name"].ToString()) + " " + __prepareName(_recipients.Rows[i]["last_name"].ToString());
                string _email_address = _recipients.Rows[i]["email_address"].ToString().ToLower();
                string _nih_invitation_code = _recipients.Rows[i]["nih_invitation_code"].ToString();

                try
                {
                    //__sendEmail("Kai", "kzheng@umich.edu", "TESTCODE");
                    __sendEmail(_name, _email_address, _nih_invitation_code);
                    Console.WriteLine((i + 1).ToString() + ", " + _study_id + ", " + _name + ", " + _email_address + ", " + _nih_invitation_code + ", sent");
                }
                catch
                {
                    Console.WriteLine((i + 1).ToString() + ", " + _study_id + ", " + _name + ", " + _email_address + ", " + _nih_invitation_code + ", failed to send");
                }
                
                if (i != _recipients.Rows.Count - 1) Thread.Sleep(5000);
            }

            Console.WriteLine("\nDone!");
            Console.ReadLine();
        }

        private static void __sendEmail(string Name, string EmailAddress, string NIHInvitationCode)
        {
            string _subject = "Invitation to Participate in NIH All of Us Study";
            string _body = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "email_template.txt");

            MailMessage _email = new MailMessage();

            LinkedResource _hoda = new LinkedResource(AppDomain.CurrentDomain.BaseDirectory + "Hoda.png", "image/png"); _hoda.ContentId = Guid.NewGuid().ToString();
            LinkedResource _logo = new LinkedResource(AppDomain.CurrentDomain.BaseDirectory + "Logo.png", "image/png"); _logo.ContentId = Guid.NewGuid().ToString();

            _body = _body.Replace("_HODA_", "<IMG src='cid:" + _hoda.ContentId + "' style='width:140px'>").Replace("_LOGO_", "<IMG src='cid:" + _logo.ContentId + "' style='width:200px'>");
            _body = _body.Replace("_NAME_", Name).Replace("_NIH_INVITATION_CODE_", NIHInvitationCode).Replace("_DATE_", DateTime.Now.ToLongDateString().Split(',')[1] + ", " + DateTime.Now.ToLongDateString().Split(',')[2]);

            AlternateView _view = AlternateView.CreateAlternateViewFromString(_body, null, "text/html");
            _view.LinkedResources.Add(_hoda); _view.LinkedResources.Add(_logo);
            _email.AlternateViews.Add(_view);

            _email.To.Add(new MailAddress(EmailAddress, Name));
            _email.Bcc.Add(new MailAddress("allofus@uci.edu", "All of Us Research Program"));
            _email.From = new MailAddress("allofus@uci.edu", "All of Us Research Program");
            _email.Subject = _subject; _email.SubjectEncoding = System.Text.Encoding.UTF8;

            _email.IsBodyHtml = true;

            SmtpClient _client = new SmtpClient();
            _client.Host = "smtp.uci.edu";
            _client.Port = 587;
            _client.EnableSsl = true;

            _client.Credentials = new NetworkCredential("allofus@uci.edu", "[Password]");

            _client.Send(_email);
            _client.Dispose();
            _email.Dispose();
        }

        private static DataTable __readCSV(string FileToRead)
        {
            DataTable _return = new DataTable(); DataRow _new_row;

            using (TextReader _tr = new StringReader(File.ReadAllText(FileToRead)))
            {
                using (CsvReader _csv = new CsvReader(_tr))
                {
                    _csv.ReadHeader(); for (int i = 0; i < _csv.FieldHeaders.Length; i++) _return.Columns.Add(_csv.FieldHeaders[i], typeof(string));

                    while (_csv.Read())
                    {
                        _new_row = _return.NewRow();
                        for (int i = 0; i < _return.Columns.Count; i++) _new_row[i] = _csv.CurrentRecord[i];
                        _return.Rows.Add(_new_row);
                    }
                }
            }

            return _return;
        }

        private static string __prepareName(string Name)
        {
            return new System.Globalization.CultureInfo("en-US", false).TextInfo.ToTitleCase(Name.ToLower());
        }
    }
}