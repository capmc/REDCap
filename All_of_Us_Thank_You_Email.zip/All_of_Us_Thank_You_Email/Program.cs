﻿using System;
using System.Net.Mail;
using System.Net;
using System.Data;
using System.IO;
using System.Threading;

namespace All_of_Us_Thank_You_Email
{
    class Program
    {
        private static string REDCAP_TOKEN = "[REDCap API Token]";

        static void Main(string[] args)
        {
            DataTable _response = REDCap.GetReport("https://ci-redcap.hs.uci.edu/api/", "&token=" + REDCAP_TOKEN + "&content=report&format=csv&report_id=1103"); // 1103 is the report "Admin: Thank-You Note to be Sent"

            DataRow[] _recipients = _response.Select("study_id NOT LIKE 'A-%' AND (email_address <> '' OR new_email_address <> '')");

            Console.WriteLine("# of participants: " + _recipients.Length.ToString("N0"));
            Console.WriteLine();

            if (_recipients.Length != 0)
            {
                Console.WriteLine("");

                for (int i = 0; i < _recipients.Length; i++)
                {
                    string _study_id = _recipients[i]["study_id"].ToString();
                    string _name = __prepareName(_recipients[i]["first_name"].ToString()) + " " + __prepareName(_recipients[i]["last_name"].ToString());
                    string _email_address = _recipients[i]["email_address"].ToString().ToLower();
                    if (_recipients[i]["new_email_address"].ToString() != "") _email_address = _recipients[i]["new_email_address"].ToString().ToLower();

                    try
                    {
                        //__sendEmail("Kai Zheng", "kzheng@umich.edu");
                        __sendEmail(_name, _email_address);
                        REDCap.ImportRecord("https://ci-redcap.hs.uci.edu/api/", "token=" + REDCAP_TOKEN + "&content=record&format=csv&data=study_id,thank_you_note_sent___yes\n" + _study_id + ",1");
                        Console.WriteLine((i + 1).ToString() + ", " + _study_id + ", " + _name + ", " + _email_address + ", sent");
                    }
                    catch
                    {
                        REDCap.ImportRecord("https://ci-redcap.hs.uci.edu/api/", "token=" + REDCAP_TOKEN + "&content=record&format=csv&data=study_id,thank_you_note_sent___yes\n" + _study_id + ",0");
                        Console.WriteLine((i + 1).ToString() + ", " + _study_id + ", " + _name + ", " + _email_address + ", failed to send");
                    }

                    if (i != _recipients.Length - 1) Thread.Sleep(90000); // has to wait for at least 1 minute, or REDCap will not be responsive.
                }

                Console.WriteLine("\nDone!");
            }
            else
            {
                Console.WriteLine("Nothing to be sent.");
            }

            Console.ReadLine();
        }

        private static void __sendEmail(string Name, string EmailAddress)
        {
            string _subject = "Thank You for Participating in All of Us!";
            string _body = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "email_template.txt");

            MailMessage _email = new MailMessage();

            LinkedResource _hoda = new LinkedResource(AppDomain.CurrentDomain.BaseDirectory + "Hoda.png", "image/png"); _hoda.ContentId = Guid.NewGuid().ToString();
            LinkedResource _logo = new LinkedResource(AppDomain.CurrentDomain.BaseDirectory + "Logo.png", "image/png"); _logo.ContentId = Guid.NewGuid().ToString();

            _body = _body.Replace("_HODA_", "<IMG src='cid:" + _hoda.ContentId + "' style='width:150px'>").Replace("_LOGO_", "<IMG src='cid:" + _logo.ContentId + "' style='width:200px'>");
            _body = _body.Replace("_NAME_", Name).Replace("_DATE_", DateTime.Now.ToLongDateString().Split(',')[1] + ", " + DateTime.Now.ToLongDateString().Split(',')[2]);

            AlternateView _view = AlternateView.CreateAlternateViewFromString(_body, null, "text/html");
            _view.LinkedResources.Add(_hoda); _view.LinkedResources.Add(_logo);
            _email.AlternateViews.Add(_view);

            _email.To.Add(new MailAddress(EmailAddress, Name));
            _email.Bcc.Add(new MailAddress("allofus@uci.edu", "All of Us Research Program"));
            _email.From = new MailAddress("allofus@uci.edu", "All of Us Research Program");
            _email.Subject = _subject; _email.SubjectEncoding = System.Text.Encoding.UTF8;

            _email.IsBodyHtml = true;

            SmtpClient _client = new SmtpClient();
            _client.Host = "smtp.uci.edu";
            _client.Port = 587;
            _client.EnableSsl = true;

            _client.Credentials = new NetworkCredential("allofus@uci.edu", "[Password]");

            _client.Send(_email);
            _client.Dispose();
            _email.Dispose();
        }

        private static string __prepareName(string Name)
        {
            return new System.Globalization.CultureInfo("en-US", false).TextInfo.ToTitleCase(Name.ToLower());
        }
    }
}