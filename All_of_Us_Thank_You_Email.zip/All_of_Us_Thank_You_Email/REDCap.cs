﻿using System.Net;
using System.IO;
using System.Data;
using System.Text;
using CsvHelper;

public class REDCap
{
    public static DataTable GetReport(string URL, string Parameters)
    {
        byte[] _parameters = Encoding.UTF8.GetBytes(Parameters);

        HttpWebRequest _web_request = (HttpWebRequest)WebRequest.Create(URL);
        _web_request.Method = "POST"; _web_request.ContentType = "application/x-www-form-urlencoded"; _web_request.ContentLength = _parameters.Length;
        using (Stream _request_stream = _web_request.GetRequestStream()) _request_stream.Write(_parameters, 0, _parameters.Length);
        HttpWebResponse _web_response = (HttpWebResponse)_web_request.GetResponse();

        string _buffer; using (Stream _response = _web_response.GetResponseStream()) using (StreamReader _reader = new StreamReader(_response)) _buffer = _reader.ReadToEnd();

        DataTable _return = new DataTable(); DataRow _new_row;

        using (TextReader _tr = new StringReader(_buffer))
        {
            using (CsvReader _csv = new CsvReader(_tr))
            {
                _csv.ReadHeader(); for (int i = 0; i < _csv.FieldHeaders.Length; i++) _return.Columns.Add(_csv.FieldHeaders[i], typeof(string));

                while (_csv.Read())
                {
                    _new_row = _return.NewRow();
                    for (int i = 0; i < _return.Columns.Count; i++) _new_row[i] = _csv.CurrentRecord[i];
                    _return.Rows.Add(_new_row);
                }
            }
        }

        return _return;
    }

    public static void ImportRecord(string URL, string Parameters)
    {
        byte[] _parameters = Encoding.UTF8.GetBytes(Parameters);

        HttpWebRequest _web_request = (HttpWebRequest)WebRequest.Create(URL);
        _web_request.Method = "POST"; _web_request.ContentType = "application/x-www-form-urlencoded"; _web_request.ContentLength = _parameters.Length;
        using (Stream _request_stream = _web_request.GetRequestStream()) _request_stream.Write(_parameters, 0, _parameters.Length);
    }
}
